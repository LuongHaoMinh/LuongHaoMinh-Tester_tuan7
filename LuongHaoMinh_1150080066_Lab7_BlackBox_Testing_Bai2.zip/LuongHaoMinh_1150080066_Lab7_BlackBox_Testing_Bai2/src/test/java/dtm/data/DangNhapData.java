package dtm.data;

import org.testng.annotations.DataProvider;

public class DangNhapData {

    @DataProvider(name = "du_lieu_dang_nhap")
    public Object[][] getData() {

        return new Object[][] {

                {"standard_user", "secret_sauce", "THANH_CONG"},
                {"locked_out_user", "secret_sauce", "BI_KHOA"},
                {"abc", "123", "SAI_THONG_TIN"},
                {"", "secret_sauce", "TRUONG_TRONG"},
                {"standard_user", "", "TRUONG_TRONG"},
                {"", "", "TRUONG_TRONG"}

        };
    }
}
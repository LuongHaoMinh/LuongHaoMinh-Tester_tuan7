package dtm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {

    private WebDriver driver;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public void moTrang() {
        driver.get("https://www.saucedemo.com");
    }

    public void nhapUsername(String username) {
        driver.findElement(By.id("user-name")).clear();
        if (username != null)
            driver.findElement(By.id("user-name")).sendKeys(username);
    }

    public void nhapPassword(String password) {
        driver.findElement(By.id("password")).clear();
        if (password != null)
            driver.findElement(By.id("password")).sendKeys(password);
    }

    public void clickLogin() {
        driver.findElement(By.id("login-button")).click();
    }

    public void dangNhap(String user, String pass) {
        nhapUsername(user);
        nhapPassword(pass);
        clickLogin();
    }

    public String layThongBaoLoi() {
        try {
            return driver.findElement(By.cssSelector("div[data-test='error']")).getText();
        } catch (Exception e) {
            return null;
        }
    }

    public boolean daVaoTrangSanPham() {
        return driver.getCurrentUrl().contains("inventory");
    }
}
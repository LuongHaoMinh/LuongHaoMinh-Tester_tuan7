package dtm.tests;

import dtm.base.BaseTest;
import dtm.data.DangNhapData;
import dtm.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC_DangNhapTest extends BaseTest {

    @Test(
            dataProvider = "du_lieu_dang_nhap",
            dataProviderClass = DangNhapData.class
    )
    public void kiemThuDangNhap(String username,
                                String password,
                                String ketQuaMongDoi) {

        LoginPage loginPage = new LoginPage(driver);
        loginPage.moTrang();
        loginPage.dangNhap(username, password);

        switch (ketQuaMongDoi) {

            case "THANH_CONG":
                Assert.assertTrue(loginPage.daVaoTrangSanPham(),
                        "Đăng nhập phải thành công");
                break;

            case "BI_KHOA":
                Assert.assertTrue(loginPage.layThongBaoLoi()
                        .contains("locked out"));
                break;

            case "SAI_THONG_TIN":
                Assert.assertNotNull(loginPage.layThongBaoLoi());
                break;

            case "TRUONG_TRONG":
                Assert.assertNotNull(loginPage.layThongBaoLoi());
                break;
        }
    }
}